import tippy from "tippy.js"

tippy("[data-tippy-content]", {
  animation: "shift-away-subtle",
  theme: "purple",
  // trigger: "click",
})
