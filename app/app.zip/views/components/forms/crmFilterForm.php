<form class="form form_view-row" action="#">
  <div class="form-control">
    <select name="publisher" id="publisher" class="js-choice custom-select">
      <option value="" disabled selected>Паблишер</option>
      <option value="vertical1">Паблишер 1</option>
      <option value="vertical2">Паблишер 2</option>
      <option value="vertical3">Паблишер 3</option>
      <option value="vertical4">Паблишер 4</option>
    </select>
  </div>
    <div class="form-control">
        <select name="status" id="status" class="js-choice custom-select">
            <option value="" disabled selected>Статус</option>
            <option value="status1">Статус 1</option>
            <option value="status2">Статус 2</option>
            <option value="status3">Статус 3</option>
        </select>
    </div>
    <div class="form-control">
      <div class="datepicker-container">
        <label class="datepicker-label">Дата напоминания:</label>
        <input type="text" class="datepicker-input" data-component="datepicker">
      </div>
    </div>
    <div class="form-control">
        <select name="traffic" id="traffic" class="js-choice custom-select" multiple data-search>
            <option value="" disabled selected>Трафик</option>
            <option value="traffic1">Трафик 1</option>
            <option value="traffic2">Трафик 2</option>
            <option value="traffic3">Трафик 3</option>
            <option value="traffic4">Трафик 4</option>
        </select>
    </div>
    <div class="form-control">
        <select name="vertical" id="vertical" class="js-choice custom-select" multiple data-search>
            <option value="" disabled selected>Вертикаль</option>
            <option value="vertical1">Вертикаль 1</option>
            <option value="vertical2">Вертикаль 2</option>
            <option value="vertical3">Вертикаль 3</option>
            <option value="vertical4">Вертикаль 4</option>
        </select>
    </div>

</form>
